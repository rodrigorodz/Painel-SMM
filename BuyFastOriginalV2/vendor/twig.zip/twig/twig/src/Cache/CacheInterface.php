<?php

namespace Twig\Cache;

class_exists('Twig_CacheInterface');

if (\false) {
    interface CacheInterface extends \Twig_CacheInterface
    {
    }
}
