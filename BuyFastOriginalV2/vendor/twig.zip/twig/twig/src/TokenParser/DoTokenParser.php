<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Do');

if (\false) {
    class DoTokenParser extends \Twig_TokenParser_Do
    {
    }
}
