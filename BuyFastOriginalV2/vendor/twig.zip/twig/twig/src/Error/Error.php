<?php

namespace Twig\Error;

class_exists('Twig_Error');

if (\false) {
    class Error extends \Twig_Error
    {
    }
}
