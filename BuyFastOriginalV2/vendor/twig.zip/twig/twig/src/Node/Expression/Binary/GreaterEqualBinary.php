<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_GreaterEqual');

if (\false) {
    class GreaterEqualBinary extends \Twig_Node_Expression_Binary_GreaterEqual
    {
    }
}
