<?php

namespace Twig;

class_exists('Twig_Environment');

if (\false) {
    class Environment extends \Twig_Environment
    {
    }
}
