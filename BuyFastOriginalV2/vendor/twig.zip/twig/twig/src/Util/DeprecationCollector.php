<?php

namespace Twig\Util;

class_exists('Twig_Util_DeprecationCollector');

if (\false) {
    class DeprecationCollector extends \Twig_Util_DeprecationCollector
    {
    }
}
