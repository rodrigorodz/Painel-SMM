<?php

namespace Twig\Extension;

class_exists('Twig_Extension');

if (\false) {
    class AbstractExtension extends \Twig_Extension
    {
    }
}
