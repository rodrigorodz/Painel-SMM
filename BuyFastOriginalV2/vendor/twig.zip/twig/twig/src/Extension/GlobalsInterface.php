<?php

namespace Twig\Extension;

class_exists('Twig_Extension_GlobalsInterface');

if (\false) {
    interface GlobalsInterface extends \Twig_Extension_ExtensionInterface
    {
    }
}
